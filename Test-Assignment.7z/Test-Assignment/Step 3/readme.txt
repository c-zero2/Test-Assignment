kustomize/
  ├── base/
  │   ├── deployment.yaml
  │   ├── service.yaml
  │   └── kustomization.yaml
  └── overlays/
      └── dev/
          ├── kustomization.yaml
          └── deployment-patch.yaml
