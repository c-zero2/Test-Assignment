terraform/
  ├── main.tf
  ├── variables.tf
  └── outputs.tf
